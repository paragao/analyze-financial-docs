import json
import boto3
import uuid
import os
import math
import stepfunctions 

comprehend = boto3.client('comprehend')
s3 = boto3.client('s3')

def download_object(request):
    print("request: {}\n".format(request))
        
    bucket = request["bucketName"]
    key = request["objectName"]

    tmpkey = key.replace('/', '')
    download_path = '/tmp/{}{}'.format(uuid.uuid4(), tmpkey)
    
    print('downloading file\n')
    s3.download_file(bucket, key, download_path)

    return download_path

def upload_object(request, textractOutput):
    print("request: {}\n".format(request))

    bucket = request["bucketName"]
    fileName = '/tmp/{}-output.json'.format(os.path.splitext(request["objectName"].lower())[0])
    new_object = 'textract_output/{}.json'.format(os.path.splitext(request["objectName"].lower())[0])

    # save JSON output as a file to be uploaded
    with open(fileName, 'w') as f:
        json.dump(textractOutput, f)
        
    print('uploading file\n')
    s3.upload_file(fileName, bucket, new_object)

def handler(event, context):
    print("event: {}\n".format(event))

    request = {}
    request["bucketName"] = event['Records'][0]['s3']['bucket']['name']
    request["objectName"] = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'])

    # initializing specific variables
    text = " "
    entities = { }

    # download the previous processed file and read it - output from the Textract call
    obj = download_object(request)
    with open(obj, 'r') as json_file:
        tmp = json.load(json_file)
        blocks = tmp["Blocks"]
    
    # extract only the blocks which are a LINE (which contain Text and WORDS within)
    for block in blocks:
        if block["BlockType"] == 'LINE':
            text = text + block["Text"] + " "

    text = text.strip()

    # step 1: get the document language
        # tip#1: the other comprehend calls required you to define what is the language of the document
    language = comprehend.detect_dominant_language(
        Text=text
    )

    # step 2: find entities
        # tip#1: detect_entities only support up to 5000 characters per call.
    if len(text) > 5000:
        loops = math.ceil(len(text) / 5000)
        for loop in loops:
            entities[loop] = comprehend.detect_entities(
                Text=text.strip()[:4999],
                LanguageCode=language
            )
            text = text[5000:]
    else: 
        entities = comprehend.detect_entities(
                Text=text,
                LanguageCode=language
            )

    # step 3: find the overall sentiment (tone) of the text
        # tip#1: 

    return {
        'statusCode': 200,
        'body': json.dumps('Success!')
    }